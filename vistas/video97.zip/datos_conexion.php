<?php

	$db_host="localhost";
    $db_nombre="pruebas";
    $db_usuario="root";
    $db_contra="";

?>
